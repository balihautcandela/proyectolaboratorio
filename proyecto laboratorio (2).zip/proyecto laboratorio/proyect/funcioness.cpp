#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "rlutil.h"
using namespace std;
#include "funciones.h"


void partidaUnJugador(int v[], int u[],int t, char nombre[]){
     ponercero(u,t);

    system("cls");
    rlutil::setBackgroundColor(rlutil::WHITE);
    rlutil::setColor(rlutil::MAGENTA);
    cout << "Modo un solo jugador" << endl;
    cout << "---------------------" << endl;

    cout << endl << "Ingrese su nombre: ";
    cin >> nombre;
    rlutil::setBackgroundColor(rlutil::BLACK);
    rlutil::setColor(rlutil::WHITE);
	for (int i = 0; i <= 5;i++) {
    system("cls");
    int puntos = 0;
    panelronda(puntos,i,u,nombre);
		while (puntos<21)
        {
            system("pause");
          system("cls");

 panelDePuntajes(u, puntos, nombre, i);


		    //cargar dados forma automatica
			tirarDados(v, u);
            //Si todos son iguales y coiciden con la ronda
			if (v[0] == i+1 && v[0] == v[1] && v[0]==v[2])
			{
				puntos = puntos+21;
				cout << "Obtuviste un BUNCO "<< endl;
				u[0]++;
            }

            //distintos a la ronda pero todos iguales
            else if (v[0] != i+1 && v[0] == v[1] && v[0] == v[2])
            {
			    puntos = puntos+5;
			    cout << "En esta tirada todos los numeros fueron iguales +5"<< endl;

            }
            //sumatoria de dados divisible por 5
            else if ((v[0]+v[1]+v[2])%5 == 0)
            {
                puntos = puntos+3;
                cout << "En esta tirada la suma de los numeros fue divisible por cinco +3"<< endl;

            }
            else
            {   //verifica si se forma escalera con los dados
                bool r = verificarEscalera(v);
                if (r)
                {
                    puntos = puntos+2;
                    cout << "En esta tirada obtuviste una escalera +2"<< endl;

                }
                else
                {
                    //contador dados coicidentes con ronda
                    int c = 0;

                    for (int j = 0; j <=2; j++)
                    {
                        if (v[j] == i+1)
                        {
                        c++;
                        }
                    }

                    //Verificacion para no sumar tres puntos mas en una combinacion
                    if (c < 3 && c >= 1)
                    {
                        if (c == 1)
                        {
                            puntos = puntos+1;
                            cout << "En esta tirada solo un dado coincidio con el numero de la ronda +1"<< endl;

                        }
                        else if (c == 2)
                        {
                            puntos = puntos+2;
                            cout << "En esta tirada solo dos dado coincidieron con el numero de la ronda +2"<< endl;

                        }

                    }
                    else
                    {
                        //tirada fallida
                        u[1]++;
                        cout << "En esta ronda no obtuviste ningun puntaje, se lo considera tirada fallida: cantidad " << u[1] << endl;
                    }
                }
            }

        system("pause");
        }
        u[3] += puntos;
	}
	system("cls");
	rlutil::setBackgroundColor(rlutil::WHITE);
    rlutil::setColor(rlutil::MAGENTA);
    cout << "Jugador: " << nombre << endl;
	cout << "Cantidad de buncos: " << u[0] << endl;
	cout << "Cantidad de tiradas fallidas: " << u[1] << endl;
    cout << "Total de lanzamientos necesarios para completar seis rondas: " << u[2] << endl;
    cout << "Subtotal de puntos sin descontar fallidas " << u[3] << endl;
    cout << "Total de puntos: " << u[3]-u[1]*2 << endl;
    system("pause");
    rlutil::setBackgroundColor(rlutil::BLACK);
    rlutil::setColor(rlutil::WHITE);
}

void tirarDados(int v[], int u[]){

    cout <<"Presione una tecla para tirar los dados" << endl;
    system("pause");

    for(int i=0; i<=2; i++) {
        v[i] =  1 + rand() % 6;
    }

    for(int i=0; i<=2; i++) {
        cout << v[i] << "\t";
    }cout << endl;
    u[2]++;
}

bool verificarEscalera(int v[]) {

	int primermayor, segundomayor, tercermayor;
	bool s;

	if (v[0]>v[1]) {
		if (v[0]>v[2]) {
			primermayor = v[0];
			if (v[1]>v[2]) {
				segundomayor = v[1];
				tercermayor = v[2];
			} else {
				segundomayor = v[2];
				tercermayor = v[1];
			}
		} else {
			primermayor = v[2];
			if (v[0]>v[1]) {
				segundomayor = v[0];
				tercermayor = v[1];
			} else {
				segundomayor = v[1];
				tercermayor = v[0];
			}
		}
	} else {
		if (v[1]>v[2]) {
			primermayor = v[1];
			if (v[0]>v[2]) {
				segundomayor = v[0];
				tercermayor = v[2];
			} else {
				segundomayor = v[2];
				tercermayor = v[0];
			}
		} else {
			primermayor = v[2];
			if (v[0]>v[1]) {
				segundomayor = v[0];
				tercermayor = v[1];
			} else {
				segundomayor = v[1];
				tercermayor = v[0];
			}
		}
	}
	s = false;
	if (((tercermayor)==(segundomayor-1) && (segundomayor)==(primermayor-1))) {
		s = true;
	}
	return s;
}

void ponercero(int u[],int t){
    int i;
for(i=0;i<t;i++){
    u[i]=0;
}
}

void panelDePuntajes(int u[], int puntos, char nombre[], int i){
    rlutil::setBackgroundColor(rlutil::MAGENTA);
    cout << "TURNO DE " << nombre;
    cout << "| Ronda #" << i+1;
    cout << "| PUNTAJE ACUMULADO: " << u[3] << " PUNTOS"<< endl;
    cout << "----------------------------------------------------"<< endl;
    cout << "VECES QUE OBTUVO BUNCO: " << u[0] << endl;
    cout << "----------------------------------------------------"<< endl;
    cout << "LANZAMIENTO #" << u[2] << endl;
    cout << "----------------------------------------------------"<< endl;
    cout << "\n\n\n\n";
    cout << "************************" << endl;
    cout << "|PUNTAJE DE LA RONDA: "<< puntos<<"|"<< endl;
    cout << "************************" << endl;
    rlutil::setBackgroundColor(rlutil::BLACK);
}

void modoSimulado(int v[], int u[],int t, char nombre[]){

     ponercero(u,t);

    system("cls");
    cout << "Modo simulado" << endl;
    cout << "---------------------" << endl;

    cout << endl << "Ingrese su nombre: ";
    cin >> nombre;

	for (int i = 0; i <= 5;i++) {
system("cls");
		int puntos = 0;
        panelronda(puntos,i,u,nombre);
		while (puntos<21)
        {
            system("pause");
            system("cls");
            panelDePuntajes(u, puntos, nombre, i);

		    //cargar dados forma manual
			cargarDados(v, u);

            //Si todos son iguales y coiciden con la ronda
			if (v[0] == i+1 && v[0] == v[1] && v[0]==v[2])
			{
				puntos = puntos+21;
				cout << "Obtuviste un BUNCO "<< endl;
				u[0]++;
            }
            //distintos a la ronda pero todos iguales
            else if (v[0] != i+1 && v[0] == v[1] && v[0] == v[2])
            {
			    puntos = puntos+5;
			    cout << "En esta tirada todos los numeros fueron iguales +5"<< endl;

            }
            //sumatoria de dados divisible por 5
            else if ((v[0]+v[1]+v[2])%5 == 0)
            {
                puntos = puntos+3;
                cout << "En esta tirada la suma de los numeros fue divisible por cinco +3"<< endl;

            }
            else
            {   //verifica si se forma escalera con los dados
                bool r = verificarEscalera(v);
                if (r)
                {
                    puntos = puntos+2;
                    cout << "En esta tirada obtuviste una escalera +2"<< endl;

                }
                else
                {
                    //contador dados coicidentes con ronda
                    int c = 0;

                    for (int j = 0; j <=2; j++)
                    {
                        if (v[j] == i+1)
                        {
                        c++;
                        }
                    }

                    //Verificacion para no sumar tres puntos mas en una combinacion
                    if (c < 3 && c >= 1)
                    {
                        if (c == 1)
                        {
                            puntos = puntos+1;
                            cout << "En esta tirada solo un dado coincidio con el numero de la ronda +1"<< endl;

                        }
                        else if (c == 2)
                        {
                            puntos = puntos+2;
                            cout << "En esta tirada solo dos dado coincidieron con el numero de la ronda +2"<< endl;

                        }

                    }
                    else
                    {
                        //tirada fallida
                        u[1]++;
                        cout << "En esta ronda no obtuviste ningun puntaje, se lo considera tirada fallida: cantidad " << u[1] << endl;

                    }
                }
            }

        u[3] += puntos;
        system("pause");
        }

	}
    system("cls");
	cout << "Cantidad de buncos: " << u[0] << endl;
	cout << "Cantidad de tiradas fallidas: " << u[1] << endl;
    cout << "Total de lanzamientos necesarios para completar seis rondas: " << u[2] << endl;
    cout << "Subtotal de puntos sin descontar fallidas " << u[3] << endl;
    cout << "Total de puntos: " << u[3]-u[1]*2 << endl;
    cout << "Jugador: " << nombre << endl;
    system("pause");
}

void cargarDados(int v[], int u[]){
    cout << "Cargue los numeros de los 3 dados:" << endl;
    cout << "----------------------------------" << endl;

	for (int i = 0; i <= 2; i++) {
		cin >> v[i];
	}
	u[2]++;


	cout << endl;
}

void panelronda(int puntos, int i, int u[], char nombre[]){
    rlutil::setBackgroundColor(rlutil::MAGENTA);
  cout << endl <<"----------------------------------------------------------";
  cout << endl <<"RONDA NUMERO:"<< i+1 <<endl;
  cout << endl <<"----------------------------------------------------------";
  cout << endl <<"PUNTAJE"<<"\t"<< nombre << ":"<< puntos <<"\t"<<"PUNTOS"<<endl;
  cout << endl <<"BUNCOS:"<< u[0] <<endl;
  cout << endl <<"TIRADAS FALLIDAS:"<< u[1]<<endl;
  cout << endl <<"LANZAMIENTOS:"<< u[2]<<endl;
  cout << endl <<"----------------------------------------------------------";

  rlutil::setBackgroundColor(rlutil::BLACK);

}


void partidaDosJugadores(int v[],int u[],int t,int u2[], int tam,char jugador1[],char jugador2[],int mayor[]){
    ponercero(u,t);
    ponercero(u2,tam);
    int c_bunco1, t_puntos1;


    system("cls");
    rlutil::setBackgroundColor(rlutil::WHITE);
    rlutil::setColor(rlutil::MAGENTA);
    cout << endl << "Ingrese el nombre del primer jugador: ";
    cin >> jugador1;
    cout << endl << "Ingrese el nombre del segundo jugador: ";
    cin >> jugador2;
rlutil::setBackgroundColor(rlutil::BLACK);
    rlutil::setColor(rlutil::WHITE);
    for (int i = 0; i <= 5;i++) {
    system("cls");
    int puntos1 = 0;
    int puntos2 = 0;
    int x1=1;
    int x2=0;


		while ((puntos1<21)&&(puntos2<21))
        {

            system("pause");
          system("cls");

             if(x1>x2){
                    x2++;
                 bool cf=false;
                    while(cf==false){
		    //cargar dados forma automatica
		    system("cls");
            panelDePuntajes(u,puntos1,jugador1,i);
			tirarDados1(v,u);

            //Si todos son iguales y coiciden con la ronda
			if (v[0] == i+1 && v[0] == v[1] && v[0]==v[2])
			{
				puntos1 = puntos1+21;
				cout << "Obtuviste un BUNCO "<< endl;
				u[0]++;
            }
            //distintos a la ronda pero todos iguales
            else if (v[0] != i+1 && v[0] == v[1] && v[0] == v[2])
            {
			    puntos1 = puntos1+5;
			    cout << "En esta tirada todos los numeros fueron iguales +5"<< endl;

            }
            //sumatoria de dados divisible por 5
            else if ((v[0]+v[1]+v[2])%5 == 0)
            {
                puntos1 = puntos1+3;
                cout << "En esta tirada la suma de los numeros fue divisible por cinco +3"<< endl;

            }
            else
            {   //verifica si se forma escalera con los dados
                bool r = verificarEscalera(v);
                if (r)
                {
                    puntos1 = puntos1+2;
                    cout << "En esta tirada obtuviste una escalera +2"<< endl;

                }
                else
                {
                    //contador dados coicidentes con ronda
                    int c = 0;

                    for (int j = 0; j <=2; j++)
                    {
                        if (v[j] == i+1)
                        {
                        c++;
                        }
                    }

                    //Verificacion para no sumar tres puntos mas en una combinacion
                    if (c < 3 && c >= 1)
                    {
                        if (c == 1)
                        {
                            puntos1 = puntos1+1;
                            cout << "En esta tirada solo un dado coincidio con el numero de la ronda +1"<< endl;

                        }
                        else if (c == 2)
                        {
                            puntos1 = puntos1+2;
                            cout << "En esta tirada solo dos dado coincidieron con el numero de la ronda +2"<< endl;

                        }

                    }
                    else
                    {
                        //tirada fallida
                        u[1]++;
                        cf=true;
                        cout << "En esta ronda no obtuviste ningun puntaje, se lo considera tirada fallida: cantidad " << u[1] << endl;
                    }
                }
            }
            if(puntos1>=21){
            cf=true;
            }
        system("pause");
          }
        system("cls");
        panelronda2(puntos1,i,u,jugador1,jugador2);
        system("pause");

             }
             else{
                 x1++;
                    bool cf=false;
                    while(cf==false){
		    //cargar dados forma automatica
		    system("cls");
		       panelDePuntajes(u2,puntos2,jugador2,i);
			tirarDados2 (v, u2);

            //Si todos son iguales y coiciden con la ronda
			if (v[0] == i+1 && v[0] == v[1] && v[0]==v[2])
			{
				puntos2 = puntos2+21;
				cout << "Obtuviste un BUNCO "<< endl;
				u[0]++;
            }
            //distintos a la ronda pero todos iguales
            else if (v[0] != i+1 && v[0] == v[1] && v[0] == v[2])
            {
			    puntos2 = puntos2+5;
			    cout << "En esta tirada todos los numeros fueron iguales +5"<< endl;

            }
            //sumatoria de dados divisible por 5
            else if ((v[0]+v[1]+v[2])%5 == 0)
            {
                puntos2 = puntos2+3;
                cout << "En esta tirada la suma de los numeros fue divisible por cinco +3"<< endl;

            }
            else
            {   //verifica si se forma escalera con los dados
                bool r = verificarEscalera(v);
                if (r)
                {
                    puntos2 = puntos2+2;
                    cout << "En esta tirada obtuviste una escalera +2"<< endl;

                }
                else
                {
                    //contador dados coicidentes con ronda
                    int c = 0;

                    for (int j = 0; j <=2; j++)
                    {
                        if (v[j] == i+1)
                        {
                        c++;
                        }
                    }

                    //Verificacion para no sumar tres puntos mas en una combinacion
                    if (c < 3 && c >= 1)
                    {
                        if (c == 1)
                        {
                            puntos2 = puntos2+1;
                            cout << "En esta tirada solo un dado coincidio con el numero de la ronda +1"<< endl;

                        }
                        else if (c == 2)
                        {
                            puntos2 = puntos2+2;
                            cout << "En esta tirada solo dos dado coincidieron con el numero de la ronda +2"<< endl;

                        }

                    }
                    else
                    {
                        //tirada fallida
                        u2[1]++;
                        cf=true;
                        cout << "En esta ronda no obtuviste ningun puntaje, se lo considera tirada fallida: cantidad " << u2[1] << endl;
                    }
                }
            }
if(puntos2>=21){
            cf=true;
          }
        system("pause");
        }
             }
             system("cls");
 panelronda2(puntos2,i,u2,jugador2,jugador1);
 system("pause");

             }
        u[3] += puntos1;
        u2[3] += puntos2;
	}
	system("cls");

	 if(u[3]>u2[3]){
        mayor[0]=u[3];
        c_bunco1=u[0];
        t_puntos1=u[3];
	 }
	 else{
            if(u2[3]>u[3]){
        mayor[0]=u2[3];
        c_bunco1=u2[0];
        t_puntos1=u2[3];
	 }
	 else{
        if(u[3]==u2[3]){
            if(u[0]>u2[0]){
                mayor[0]=u[3];
                c_bunco1=u[0];
                t_puntos1=u[3];
            }
            else{
                if(u2[0]>u[0]){
                    mayor[0]=u2[3];
                    c_bunco1=u2[0];
                    t_puntos1=u2[3];
                }
                else(u2[0]==u[0]);{
                    mayor[0]=1;
                }
            }
        }
	 }
	 }

   rlutil::setBackgroundColor(rlutil::WHITE);
    rlutil::setColor(rlutil::MAGENTA);
    if(mayor[0]==u[3]){
    cout <<"GANADOR:" << jugador1 << endl; }
    else{ if(mayor[0]==u2[3]){
    cout << "GANADOR:" << jugador2<< endl;}
    else{ if(mayor[0]==1){ cout<< "EMPATE" << endl; }}
    }
    cout << "Cantidad de buncos: " << c_bunco1 << endl;
    cout << "Total de puntos: " << t_puntos1 << endl << endl;

    system("pause");
    rlutil::setBackgroundColor(rlutil::BLACK);
    rlutil::setColor(rlutil::WHITE);
}

    void tirarDados2(int v[], int u[]){

    cout <<"Presione una tecla para tirar los dados" << endl;
    system("pause");

    for(int i=0; i<=2; i++) {
        v[i] =  1 + rand() % 6;
    }

    for(int i=0; i<=2; i++) {
        cout << v[i] << "\t";
    }cout << endl;
    u[2]++;
    }

    void tirarDados1(int v[], int u2[]){

    cout <<"Presione una tecla para tirar los dados" << endl;
    system("pause");

    for(int i=0; i<=2; i++) {
        v[i] =  1 + rand() % 6;
    }

    for(int i=0; i<=2; i++) {
        cout << v[i] << "\t";
    }cout << endl;
    u2[2]++;
    }

    void panelronda2(int puntos, int i, int u[], char nombre1[],char nombre2[]){
        rlutil::setBackgroundColor(rlutil::MAGENTA);

  cout << endl <<"-----------------------------------";
  cout << endl <<"RONDA NUMERO:"<< i+1 <<endl;
  cout << endl <<"PROXIMO TURNO:" << nombre2;
  cout << endl <<"-----------------------------------";
  cout << endl <<"PUNTAJE"<<"\t"<< nombre1 << ":"<< puntos <<"\t"<<"PUNTOS"<<endl;
  cout << endl <<"CANTIDAD DE BUNCOS:"<< u[0]<<endl;
  cout << endl <<"-----------------------------------";
  cout << endl <<"TIRADAS FALLIDAS:"<< u[1] <<endl;
  cout << endl <<"LANZAMIENTOS:"<< u[2] <<endl;
  cout << endl <<"-----------------------------------";

  rlutil::setBackgroundColor(rlutil::BLACK);
}

void mayorpuntuacion(int mayor[],char jugador1[],char jugador2[],int anterior[],int u[],int u2[]){

    if(anterior[0]==0){
        if(mayor[0]==u[3]){
                rlutil::setBackgroundColor(rlutil::WHITE);
                rlutil::setColor(rlutil::MAGENTA);
            cout<<"LA MAYOR PUNTUACION HASTA EL MOMENTO ES DEL JUGADOR:"<<"\t"<<jugador1<<"\t"<<"CON UN TOTAL DE"<<"\t"<<mayor[0]<<"\t"<<"PUNTOS"<<endl;

        }
        else{
            cout<<"LA MAYOR PUNTUACION HASTA EL MOMENTO ES DEL JUGADOR:"<<"\t"<<jugador2<<"\t"<<"CON UN TOTAL DE"<<"\t"<<mayor[0]<<"\t"<<"PUNTOS"<<endl;

        }
        anterior[0]=mayor[0];
        }
        else{
            if(anterior[1]>mayor[0]){
                    if(anterior[0]==u[3]){
                        cout<<"LA MAYOR PUNTUACION HASTA EL MOMENTO ES DEL JUGADOR:"<<"\t"<<jugador1<<"\t"<<"CON UN TOTAL DE"<<"\t"<<anterior[0]<<"PUNTOS";
                    }
                    else{
                        cout<<"LA MAYOR PUNTUACION HASTA EL MOMENTO ES DEL JUGADOR:"<<"\t"<<jugador2<<"\t"<<"CON UN TOTAL DE"<<"\t"<<anterior[0]<<"PUNTOS";
                    }
            }
            else{
                if(mayor[0]==u[3]){
            cout<<"LA MAYOR PUNTUACION HASTA EL MOMENTO ES DEL JUGADOR:"<<"\t"<<jugador1<<"\t"<<"CON UN TOTAL DE"<<"\t"<<mayor[0]<<"\t"<<"PUNTOS"<<endl;

        }
        else{
            cout<<"LA MAYOR PUNTUACION HASTA EL MOMENTO ES DEL JUGADOR:"<<"\t"<<jugador2<<"\t"<<"CON UN TOTAL DE"<<"\t"<<mayor[0]<<"\t"<<"PUNTOS"<<endl;
        }
        anterior[0]=mayor[0];
            }
        }
        system("pause");
        rlutil::setBackgroundColor(rlutil::BLACK);
        rlutil::setColor(rlutil::WHITE);
}

void reglamento(){
    rlutil::setBackgroundColor(rlutil::MAGENTA);
 cout<< endl <<"REGLAMENTO DEL JUEGO:";
 cout<< endl <<"BUNCO es un juego que utiliza 3 dados.";
 cout<< endl <<"Consiste en 6 rondas, las cuales progresan consecutivamente.";
 cout<< endl <<"Los puntos de cada tirada se evaluan de la siguiente manera:"<<"\t";
 cout<< endl << endl;
 cout<< endl <<"21 PUNTOS SI LOS TRES DADOS COINCIDEN CON EL NUMERO DE LA RONDA QUE SE";
 cout<< endl <<"ESTA JUGANDO:";
 cout<< endl <<"A ESTA TIRADA SE LA DENOMINA BUNCO.";
 cout<< endl <<"5 PUNTOS SI LOS TRES DADOS SON IGUALES PERO NO COINCIDEN CON EL NUMERO";
 cout<< endl <<"DE LA RONDA EN CURSO.";
cout<< endl <<"3 PUNTOS SI LA SUMA DE LOS TRES DADOS ES DIVISIBLE POR 5.";
cout<< endl <<"2 PUNTOS SI LOS TRES DADOS FORMAN UNA ESCALERA.";
cout<< endl <<"1 PUNTO POR CADA DADO QUE COINCIDA CON EL NUMERO DE RONDA QUE SE ESTA";
cout<< endl <<"JUGANDO."<<"\t";
cout<< endl <<"CABE ACLARAR que de obtener mas de una combinacion de puntos, en el";
cout<< endl <<"mismo lanzamiento, se suma unicamente el puntaje mayor."<<"\t";
 cout<< endl <<"Una tirada que no obtenga ningun puntaje, se la considera";
 cout<< endl <<"TIRADA FALLIDA."<<"\t";
cout<< endl <<"MODO UN JUGADOR:";
cout<< endl <<"Cada ronda termina cuando el jugador llega a un puntaje mayor o";
cout<< endl <<"igual a 21.";
cout<< endl <<"Al finalizar todas las rondas, al puntaje final se le restara un total";
cout<< endl <<"de dos puntos por cada TIRADA FALLIDA."<<"\t";
cout<< endl <<"MODO DOS JUGADORES:";
 cout<< endl <<"Cada ronda termina cuando uno de los dos jugadores obtiene";
 cout<< endl <<"un puntaje mayor o igual a 21.";
cout<< endl <<"El jugador puede seguir realizando lanzamientos mientras no realize";
cout<< endl <<"ninguna tirada fallida, o llegue a un puntaje mayor o igual a 21."<<"\t";
cout<< endl <<"MODO SIMULADO:";
cout<< endl <<"Este modo es para UN SOLO JUGADOR";
cout<< endl <<"Con la diferencia de cargar los dados MANUALMENTE.";
 cout<< endl <<"EL GANADOR DE LA PARTIDA es aquel jugador que obtenga el puntaje";
 cout<< endl <<"mas alto,";
cout<< endl <<"En caso de PARIDAD gana el que tenga mayor cantidad de puntos."<<"\t";
cout<< endl <<"EMPATE:";
cout<< endl <<"Se dara un empate solamente si ambos jugadores obtienen el mismo";
cout<< endl <<"puntaje y la misma cantidad de buncos al finalizar la partida."<<"\t";
 system("pause");
 rlutil::setBackgroundColor(rlutil::BLACK);
}

