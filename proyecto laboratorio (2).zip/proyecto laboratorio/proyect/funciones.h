#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

void menu();
void ponercero(int u[],int t);
void partidaUnJugador(int v[], int u[],int t, char nombre[]);
void tirarDados(int v[], int u[]);
bool verificarEscalera(int v[]);
void cargarDados(int v[], int u[]);
void panelDePuntajes(int u[], int puntos, char nombre[], int i);
void modoSimulado(int v[], int u[], int t, char nombre[]);
void panelronda(int puntos, int i, int u[], char nombre[]);
void partidaDosJugadores(int v[],int u[],int t,int u2[],int tam,char jugador1[],char jugador2[],int mayor[]);
void tirarDados2(int v[], int u[]);
void panelronda2(int puntos, int i, int u[], char nombre1[],char nombre2[]);
void tirarDados1(int v[], int u2[]);
void mayorpuntuacion(int mayor[],char jugador1[],char jugador2[],int anterior[],int u[],int u2[]);
void reglamento();
#endif // FUNCIONES_H_INCLUDED
