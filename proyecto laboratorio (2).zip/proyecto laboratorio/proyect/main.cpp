#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include "rlutil.h"


using namespace std;
#include "funciones.h"
int main()
{
 void   menu();{
    int tirada[3];
    char nombre[10];
    int v[4];
    int v2[4];
    char jugador1[10];
    char jugador2[10];
    int mayor[1]={0};
    int anterior[1]={0};

    int opc;

    do {
            rlutil::setBackgroundColor(rlutil::WHITE);
            rlutil::setColor(rlutil::MAGENTA);
        system("cls");
        cout << "Bienvenido a BUNCO!!"<< endl;
        cout << "--------------------"<< endl;

        cout << endl << "1.- Juego nuevo para un jugador.";
        cout << endl << "2.- Juego nuevo para dos jugadores.";
        cout << endl << "3.- Mostrar puntuacion mas alta.";
        cout << endl << "4.- Modo Simulado.";
        cout << endl << "5.- Reglamento del juego.";
        cout << endl << "0.- Salir." << endl << endl << "-> ";
        cin >> opc;
        rlutil::setBackgroundColor(rlutil::BLACK);
rlutil::setColor(rlutil::WHITE);
        switch(opc) {

            case 1:
                //Un jugador
                partidaUnJugador(tirada,v,4,nombre);
                break;
            case 2:
                partidaDosJugadores(tirada,v,4,v2,4,jugador1,jugador2,mayor);
                break;
            case 3:
                mayorpuntuacion(mayor,jugador1,jugador2,anterior,v,v2);
                break;
            case 4:
                modoSimulado(tirada,v,4,nombre);
                break;
            case 5:
                reglamento();
                break;
        }

    }while(opc != 0);
    return 0;
}
}
